// Put your applicaiton javascript here

console.log( "#fff800");