server we host our databases

portfolio - database
cars - collection

a bunch of documents inside of a collection

var civic = {
  title: 'civic',
  company: 'honda',
  doors: 2
}

var ml350 = {
  title: 'ML350',
  company: 'Mercedes Benz',
  doors: 4
}

var supra = {
  title: 'supra',
  company: 'Toyota'
  doors: 2
}

var eclass = {
  title: 'ECLASS',
  company: 'Mercedes'
}
