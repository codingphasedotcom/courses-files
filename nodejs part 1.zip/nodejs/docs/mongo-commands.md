Commands
mongod - start mongodb
mongo - go to commandline of mongodb
help - show all the commands
use - use a specific database or create a new one
show dbs - show all databases
insert - insert a document into a collection or create a new one
update - update a document in a collection
find - find a specific document or show all documents
remove - remove a document
