<template>
  <h2>This is a {{ framework }} application</h2>
</template>

<script>
export default {
  data() {
    return { framework: "VueJS"}
  }
}
</script>

<style lang="scss" scoped>
  h1{
    color: black;
  }
</style>
