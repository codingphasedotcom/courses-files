var numbers = {
  "Johny": 23,
  "James": 25,
  "Years": 2
}
export default numbers
