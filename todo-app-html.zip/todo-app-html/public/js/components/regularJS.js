webpackJsonp([0],[
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


console.log('Welcome To The Rocky Stack');

/***/ })
],[0]);