export default function AnnounceBar() {
  return(
    <div className="announce-bar">
      50% Sale On July 4th 2028
    </div>
  )
}