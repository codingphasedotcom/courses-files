webpackJsonp([0],{

/***/ 98:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


console.log('testing javascript2');

/***/ })

},[98]);