<?php $__env->startSection('title'); ?>
  Account - Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div>
    <div class="row">
      <div class="col-md-10">
        <h1>Edit Project</h1>
        <h6>This is where all your projects are located</h6>
      </div>

    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="box">
          <div class="row">
            <div class="col-md-10">
              <form action="/account/projects/<?php echo e($project->id); ?>" method="POST">
                 <?php echo e(csrf_field()); ?>

                 <?php echo e(method_field('PUT')); ?>

                <div class="row">
                  <div class="col-md-6">
                    <label for="title">
                      Title
                    </label>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <input type="text" name="title" value="<?php echo e($project->title); ?>">
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <label for="title">
                      Active
                    </label>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <select name="active">
                      <?php if($project->active == 0): ?>
                        <option value="0" selected>No</option>
                        <option value="1" >Yes</option>
                      <?php else: ?>
                        <option value="0" >No</option>
                        <option value="1" selected>Yes</option>
                      <?php endif; ?>
                    </select>
                  </div>
                </div>
                <div class="img-section">
                  <div class="row">
                    <?php $__currentLoopData = $project->inspirations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inspiration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-3">
                        <div class="box">
                          <div style="position: relative; background: url('<?php echo e($inspiration->image_url); ?>') no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover; height: 200px;"></div>
                          <a href="/projects/inspiration/<?php echo e($inspiration->image_info); ?>/delete">Delete</a>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>


                <button type="submit">Save</button>
              </form>
            </div>
          </div>
          <div class="col-md-2">
            <center>
              <a href="/account/projects/<?php echo e($project->id); ?>/delete" onclick="confirm()" class="delete-btn">Delete</a>
            </center>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.bundle.js"></script>
  <script>

  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/account', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>