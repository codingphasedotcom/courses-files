<?php $__env->startSection('title'); ?>
  Design Storm - Inspiration for developers
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  <div id="site-section">
    <div class="container">
      <div id="results">
        <div>
          <div class="search-container">
            <form action="/results" method="POST">
              <?php echo e(csrf_field()); ?>

              <input class="search" type="text" value="<?php echo e($keyword); ?>" placeholder="Search" name="search">
            </form>
          </div>
          <div class="boxes">
            <div class="row">
              <?php if(count($filteredData) >= 1): ?>
                <?php $__currentLoopData = $filteredData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inspiration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-3">
                    <div class="box">
                      <div style="position: relative; background: url('<?php echo e($inspiration->covers->{'202'}); ?>') no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover; height: 200px;">
                        <?php
                        $codedUrl = urlencode($inspiration->covers->{'202'})
                        ?>
                        <a href="/projects/inspiration/<?php echo e($inspiration->id); ?>/add?image_url=<?php echo e($codedUrl); ?>">
                          <div class="add-btn <?php if(in_array($inspiration->id, $arrayInfo)): ?>
                            active
                          <?php endif; ?>">
                          <i class="fa fa-check" aria-hidden="true"></i></div>
                        </a>
                      </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <h1>Sorry No Results</h1>
              <?php endif; ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>