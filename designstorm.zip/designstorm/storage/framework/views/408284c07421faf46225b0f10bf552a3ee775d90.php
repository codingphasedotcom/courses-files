<?php $__env->startSection('title'); ?>
  Account - Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div>
    <div class="row">
      <div class="col-md-10">
        <h1><?php echo e($project->title); ?></h1>
        <h6>This is where all your projects are located - <strong style="color: red">Author: <?php echo e($project->user->name); ?></strong></h6>
      </div>

    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="box">
          <div class="row">
            <div class="col-md-10">


                <div class="img-section">
                  <div class="row">
                    <?php $__currentLoopData = $project->inspirations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inspiration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-3">
                        <div class="box">
                          <div style="position: relative; background: url('<?php echo e($inspiration->image_url); ?>') no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover; height: 200px;"></div>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
          </div>
          <div class="col-md-2">
            <center>
              <a href="/account/projects/<?php echo e($project->id); ?>/edit" class="edit-btn">Edit</a>
              <a href="/account/projects/<?php echo e($project->id); ?>/delete" onclick="confirm()" class="delete-btn">Delete</a>
            </center>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.bundle.js"></script>
  <script>

  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/account', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>