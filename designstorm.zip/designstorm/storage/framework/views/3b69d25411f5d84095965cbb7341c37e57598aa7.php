<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <script async="" defer="" src="https://buttons.github.io/buttons.js"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
  </head>
  <body>
    <header>
      <div class="container"><a class="logo" href="/">Design Storm</a>
        <nav>
          <?php if(auth()->guard()->guest()): ?>

          <a href="/register">register</a>
          <a href="/login">login</a>

          <?php else: ?>
            <a href="/account"><?php echo e($user->name); ?></a>
            <a href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();">
                Logout
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
          <?php endif; ?>
          </nav>
      </div>
    </header>
    <?php echo $__env->yieldContent('content'); ?>
  </body>
</html>
