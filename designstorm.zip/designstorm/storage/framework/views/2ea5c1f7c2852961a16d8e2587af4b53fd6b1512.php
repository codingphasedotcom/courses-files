<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <script async="" defer="" src="https://buttons.github.io/buttons.js"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
  </head>
  <body>
    <div id="admin-section">
      <div id="sidemenu">
        <div class="logo"> </div>
        <nav>
          <a class="active" href="/account">
            <i class="fa fa-tachometer" aria-hidden="true"></i>Dashboard
          </a>
          <a class="active" href="/account/projects">
            <i class="fa fa-briefcase" aria-hidden="true"></i>Projects
          </a>
        </nav>
      </div>
      <div id="content-area">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </div>
  </body>
</html>
